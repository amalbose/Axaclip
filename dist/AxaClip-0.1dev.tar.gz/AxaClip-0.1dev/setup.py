from distutils.core import setup

setup(
    name='AxaClip',
    version='0.1dev',
    packages=['axaclip',],
    license='GNU GPL',
    long_description=open('README.md').read(),
)